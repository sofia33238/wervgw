// TTAds Hub — сервис-воркер: маршрутизация сообщений интерфейса и движки инструментов.
import { friendlyError, HubError, parseAdsUrl, requireAdsTab } from './lib/page.js';
import { clearJournal, getSettings, log, patchSettings, readJournal, saveSettings } from './lib/storage.js';
import { VERSION } from './lib/constants.js';
import * as manual from './manual/engine.js';
import * as appeals from './appeals/engine.js';
import { sendTestEvent } from './s2s/events.js';
import { createPixelInPage } from './s2s/pixel.js';
import { runInPage } from './lib/page.js';

// Слушатели регистрируются синхронно при загрузке воркера (требование MV3).
manual.registerManualListeners();

chrome.runtime.onInstalled.addListener((details) => {
  log('info', 'sys', details.reason === 'install' ? `Установлен TTAds Hub ${VERSION}` : `TTAds Hub обновлён до ${VERSION}`);
});

// Связь со страницей: если агент ещё не внедрён (вкладку открыли до установки), внедряем его и повторяем.
async function agentCall(tabId, message) {
  const send = () => chrome.tabs.sendMessage(tabId, message);
  try { return await send(); } catch {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content/agent.js'] });
      return await send();
    } catch { return null; }
  }
}

const handlers = {
  'manual.status': async ({ tabId }) => {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    const info = parseAdsUrl(tab?.url ?? '');
    if (!tab || !info.ok) return { onAds: false, url: tab?.url ?? '' };
    const [state, agent] = await Promise.all([manual.getState(tabId, tab.url), agentCall(tabId, { type: 'agent.info' })]);
    return { onAds: true, url: tab.url, state, agent };
  },
  'manual.activate': async ({ tabId, account }) => {
    const { tab, info } = await requireAdsTab(tabId);
    if (account && info.account !== account) throw new HubError('Кабинет на вкладке изменился. Проверьте экран и повторите.');
    const result = await manual.activate(tabId, tab.url);
    if (result?.error) throw new HubError(result.error);
    return result;
  },
  'manual.cancel': ({ tabId }) => manual.cancel(tabId),
  'manual.timezone': async ({ tabId }) => {
    await requireAdsTab(tabId);
    return (await agentCall(tabId, { type: 'agent.timezone' })) ?? { page: null };
  },
  'manual.interceptor': async ({ tabId, enabled }) => {
    await requireAdsTab(tabId);
    const settings = await getSettings();
    const reply = await agentCall(tabId, { type: 'agent.setInterceptor', enabled: Boolean(enabled), fields: settings.manual.fields });
    if (!reply?.ok) throw new HubError('Не удалось переключить режим. Обновите страницу TikTok (F5) и повторите.');
    log('info', 'mnl', enabled ? 'Перехват флагов включён, страница перезагружается' : 'Перехват флагов выключен, страница перезагружается');
    return { ok: true };
  },

  'appeals.scan': ({ tabId }) => appeals.scan(tabId),
  'appeals.resolve': ({ tabId, account, rows }) => appeals.resolveNested(tabId, account, rows),
  'appeals.start': ({ tabId, account, rows, text, reason }) => appeals.startBatch({ tabId, account, rows, text, reason }),
  'appeals.batch': () => appeals.getBatch(),
  'appeals.cancel': () => appeals.cancelBatch(),
  'appeals.history': () => appeals.history(),
  'appeals.unblock': ({ jobId }) => appeals.unblock(jobId),
  'appeals.clear': () => appeals.clearHistory(),

  's2s.test': async ({ input }) => {
    const result = await sendTestEvent(input);
    log(result.ok ? 'info' : 'warn', 's2s', `Тест события ${input.event} (API ${result.api}): ${result.ok ? 'принято' : `код ${result.code ?? result.http}: ${result.message}`}`);
    return result;
  },
  's2s.pixel': async ({ tabId, options }) => {
    const { info } = await requireAdsTab(tabId);
    if (!info.account) throw new HubError('В адресе вкладки нет aadvid. Откройте нужный рекламный кабинет.');
    const result = await runInPage(tabId, createPixelInPage, [{ ...options, aadvid: info.account }]);
    if (!result || result.error) throw new HubError(result?.error || 'Не удалось создать пиксель.');
    log('info', 's2s', `Создан пиксель ${result.pixelCode}${result.devToken ? ' (token получен)' : ' (token не получен)'}`);
    return result;
  },

  'journal.get': () => readJournal(),
  'journal.clear': async () => { await clearJournal(); return { ok: true }; },
  'settings.get': () => getSettings(),
  'settings.save': ({ settings }) => saveSettings(settings),
  'settings.patch': ({ patch }) => patchSettings(patch)
};

// Токен-бакет: не больше ~1 записи MNL в секунду (всплеск до 60), чтобы страница не вытеснила журнал.
const mnlBucket = { tokens: 60, at: Date.now() };
function allowMnlLog() {
  const now = Date.now();
  mnlBucket.tokens = Math.min(60, mnlBucket.tokens + (now - mnlBucket.at) / 1000);
  mnlBucket.at = now;
  if (mnlBucket.tokens < 1) return false;
  mnlBucket.tokens -= 1;
  return true;
}

function handleAgentMessage(message, sender) {
  if (message.type !== 'edits' || !sender.tab || !parseAdsUrl(sender.tab.url ?? '').ok) return;
  const merged = new Map();
  for (const item of Array.isArray(message.items) ? message.items.slice(0, 20) : []) {
    const text = `${item.direction === 'response' ? '←' : '→'} ${String(item.path || '').slice(0, 120)}: ${(item.keys || []).map(String).join(', ')}`;
    merged.set(text, (merged.get(text) ?? 0) + 1);
  }
  for (const [text, count] of merged) if (allowMnlLog()) log('info', 'mnl', count > 1 ? `${text} ×${count}` : text);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || !message || typeof message !== 'object') return false;
  if (message.ns === 'agent') { handleAgentMessage(message, sender); return false; }
  // Команды принимаем только от страниц самого расширения.
  if (!sender.url?.startsWith(chrome.runtime.getURL(''))) return false;
  const handler = handlers[`${message.ns}.${message.type}`];
  if (!handler) return false;
  handler(message, sender).then(
    (data) => sendResponse({ ok: true, data }),
    (error) => sendResponse({ ok: false, error: friendlyError(error), code: error?.code ?? 'error' })
  );
  return true;
});
